﻿using BepInEx;
using Cristalmaterial;
using System;
using System.Timers;
using UnityEngine;
using Utilla;
using TMPro;
using GorillaLocomotion.Climbing;
using GorillaTag.Cosmetics;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cristalcomputer
{
    /// <summary>
    /// This is your mod's main class.
    /// </summary>

    /* This attribute tells Utilla to look for [ModdedGameJoin] and [ModdedGameLeave] */
    [ModdedGamemode]
    [BepInDependency("org.legoandmars.gorillatag.utilla", "1.5.0")]
    [BepInPlugin(PluginInfo.GUID, PluginInfo.Name, PluginInfo.Version)]
    public class Plugin : BaseUnityPlugin
    {
        bool inRoom;
        public GameObject sourceObject;
        public GameObject targetObject;
        public GameObject stand;
        public GameObject fistbump;
        public GameObject highfive;
        public GameObject cristal;

        void Start()
        {
            /* A lot of Gorilla Tag systems will not be set up when start is called /*
			/* Put code in OnGameInitialized to avoid null references */

            Utilla.Events.GameInitialized += OnGameInitialized;
        }

        void OnEnable()
        {
            /* Set up your mod here */
            /* Code here runs at the start and whenever your mod is enabled*/

            HarmonyPatches.ApplyHarmonyPatches();
        }

        void OnDisable()
        {
            /* Undo mod setup here */
            /* This provides support for toggling mods with ComputerInterface, please implement it :) */
            /* Code here runs whenever your mod is disabled (including if it disabled on startup)*/

            HarmonyPatches.RemoveHarmonyPatches();
        }

        async void OnGameInitialized(object sender, EventArgs e)
        {
            GameObject cristal = GameObject.Find("Environment Objects/LocalObjects_Prefab/ForestToCave/C_Crystal_Chunk");
            Material renderer = cristal.GetComponent<Renderer>().material;

            GameObject computer = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/GorillaComputerObject/ComputerUI/monitor");
            computer.GetComponent<Renderer>().material = renderer;

            GameObject plane = GameObject.CreatePrimitive(PrimitiveType.Plane);
            plane.GetComponent<Renderer>().material = renderer;
            plane.transform.position = new Vector3(-65.4705f, 11.9719f, -80.004f);
            plane.transform.rotation = Quaternion.Euler(275.1958f, 20.35f, -0.0005f);
            plane.transform.localScale = new Vector3(0.07f, 0.1f, 0.04f);

            GameObject plane2 = GameObject.CreatePrimitive(PrimitiveType.Plane);
            plane2.GetComponent<Renderer>().material = renderer;
            plane2.transform.position = new Vector3(-66.65f, 12.85f, - 80.3f);
            plane2.transform.rotation = Quaternion.Euler(330.056f, 182.7964f, 180.1f);
            plane2.transform.localScale = new Vector3(0.09f, 0.1f, 0.042f);

            GameObject plane3 = GameObject.CreatePrimitive(PrimitiveType.Plane);
            plane3.GetComponent<Renderer>().material = renderer;
            plane3.transform.position = new Vector3(-67.96f, 11.95f, - 80.7f);
            plane3.transform.rotation = Quaternion.Euler(276.3606f, 332.0349f, 0.1003f);
            plane3.transform.localScale = new Vector3(0.106f, 0.1f, 0.106f);

            GameObject plane4 = GameObject.CreatePrimitive(PrimitiveType.Plane);
            plane4.GetComponent<Renderer>().material = renderer;
            plane4.transform.position = new Vector3(-65.44f, 12.33f, - 84.6f);
            plane4.transform.rotation = Quaternion.Euler(0f, 48.998f, 90f);
            plane4.transform.localScale = new Vector3(0.07f, 0.1f, 0.16f);


            GameObject keyboard1 = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/GorillaComputerObject/ComputerUI/keyboard (1)");
            keyboard1.GetComponent<Renderer>().material = renderer;

            Transform keyboard = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/GorillaComputerObject/ComputerUI/keyboard (1)/Buttons").transform;
            MeshRenderer[] keys = keyboard.GetComponentsInChildren<MeshRenderer>();
            foreach (MeshRenderer renderer1 in keys)
            {
                renderer1.material = renderer;
                renderer1.GetComponent<Renderer>().material.color = new Color(1, 1, 1, 1);
                renderer.color = new Color(0.4548f, 0.26f, 0.58f, 1f);
            }

            GameObject screentext1 = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/FunctionSelect");
            screentext1.GetComponent<TextMeshPro>().color = new Color(1, 0, 1, 1);
            

            GameObject screentext2 = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/Data");
            screentext2.GetComponent<TextMeshPro>().color = new Color(1, 0, 1, 1);

            GameObject coc = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/CodeOfConduct");
            coc.transform.position = new Vector3(-67.93f, 11.9661f, - 80.6928f);

            GameObject coctext = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/COC Text");
            coctext.transform.position = new Vector3(-68.29f, 11.4147f, - 80.9588f);


            Transform treeroom = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom").transform;
            TextMeshPro[] key = treeroom.GetComponentsInChildren<TextMeshPro>();
            foreach (TextMeshPro renderer2 in key)
            {
                renderer2.color = new Color(1, 0, 1, 1);
            }

            

        }


        void Update()
        {
            /* Code here runs every frame when the mod is enabled */
            GameObject cristal = GameObject.Find("Environment Objects/LocalObjects_Prefab/ForestToCave/C_Crystal_Chunk");
            Material renderer = cristal.GetComponent<Renderer>().material;
            GameObject mat = GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/LBAGI./SamuraiArmor");
            mat.GetComponent<SkinnedMeshRenderer>().material = renderer;
            GameObject slingshot = GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/CosmeticBodyAnchorOverrides/SlingshotAnchors/SlingshotAnchor_Tees/DropZoneAnchor/LMABB./HornsSlingshot/HornsSlingshot");
            slingshot.GetComponent<MeshRenderer>().material = renderer;
            GameObject claw = GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/LMAJO./DragonClaw");
            claw.GetComponent<SkinnedMeshRenderer>().material = renderer;

            //GameObject rc = GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.L/upper_arm.L/forearm.L/TransferrableItemLeftArm/DropZoneAnchor/RCRemoteAnchorBlimpVariant(Clone)/LMAKJ.");
            //rc.AddComponent<GorillaClimbable>();

        }

        /* This attribute tells Utilla to call this method when a modded room is joined */
        [ModdedGamemodeJoin]
        public void OnJoin(string gamemode)
        {
            /* Activate your mod here */
            /* This code will run regardless of if the mod is enabled*/

            inRoom = true;
        }

        /* This attribute tells Utilla to call this method when a modded room is left */
        [ModdedGamemodeLeave]
        public void OnLeave(string gamemode)
        {
            /* Deactivate your mod here */
            /* This code will run regardless of if the mod is enabled*/

            inRoom = false;
        }
    }
}
