﻿namespace Cristalcomputer
{
    /// <summary>
    /// This class is used to provide information about your mod to BepInEx.
    /// </summary>
    internal class PluginInfo
    {
        public const string GUID = "com.boxtroll.gorillatag.unusedmirrorobjects";
        public const string Name = "crystal computer";
        public const string Version = "1.0.0";
    }
}
